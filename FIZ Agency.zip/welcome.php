<?php
$include = file_get_contents('http://www.exabytes.com.my/welcome/include/index-linux.php');
echo $include;
?>
